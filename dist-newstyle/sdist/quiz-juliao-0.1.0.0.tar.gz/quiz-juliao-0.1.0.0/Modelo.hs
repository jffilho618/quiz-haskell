module Modelo where

-- | Tipo algébrico para categorias de perguntas
data Categoria = Historia | Ciencias | CulturaPop deriving (Show, Eq, Read)

-- | Tipo algébrico para perguntas (produto com campos)
data Pergunta = Pergunta
    { texto :: String
    , opcoes :: [String]
    , correta :: Int
    , categoria :: Categoria
    } deriving (Show, Read)

-- | Tipo algébrico para ajudas disponíveis
data Ajuda = Pular | Eliminar | Universitarios deriving (Show, Eq)

-- | Tipo abstrato para o estado do jogo
data ShowJ = ShowJ
    { perguntas :: [Pergunta]
    , pontuacao :: Int
    , premio :: Int
    , ajudas :: [Ajuda]
    , respondidas :: [Pergunta]
    }

-- | Cria um novo estado do jogo
novoShow :: [Pergunta] -> ShowJ
novoShow ps = ShowJ
    { perguntas = ps
    , pontuacao = 0
    , premio = 0
    , ajudas = [Pular, Eliminar, Universitarios]
    , respondidas = []
    }

-- | Adiciona uma pergunta ao estado
adicionarPergunta :: ShowJ -> Pergunta -> ShowJ
adicionarPergunta show p = show { perguntas = p : perguntas show }

-- | Remove uma pergunta pelo texto
removerPergunta :: ShowJ -> String -> ShowJ
removerPergunta show txt = show { perguntas = filter (\p -> texto p /= txt) (perguntas show) }

-- | Registra uma resposta, atualizando pontuação e prêmio
responderPergunta :: ShowJ -> Pergunta -> Int -> ShowJ
responderPergunta show p resp =
    let novaPontuacao = if resp == correta p then pontuacao show + 1 else pontuacao show
        novoPremio = if resp == correta p then calcularPremio (novaPontuacao) else premio show
        novasRespondidas = p : respondidas show
    in show { pontuacao = novaPontuacao, premio = novoPremio, respondidas = novasRespondidas }

-- | Usa uma ajuda, removendo-a do estado
usarAjuda :: ShowJ -> Ajuda -> ShowJ
usarAjuda show ajuda = show { ajudas = filter (/= ajuda) (ajudas show) }

-- | Calcula o prêmio com base na pontuação
calcularPremio :: Int -> Int
calcularPremio pontos = case pontos of
    0 -> 0
    1 -> 1000
    2 -> 2000
    3 -> 5000
    4 -> 10000
    5 -> 20000
    6 -> 50000
    7 -> 100000
    8 -> 200000
    9 -> 500000
    _ -> 1000000

-- | Classe de tipo para exibir elementos
class Exibivel a where
    exibir :: a -> String

-- | Instância para exibir perguntas
instance Exibivel Pergunta where
    exibir p = texto p ++ "\n" ++ unlines (zipWith (\i o -> show i ++ ". " ++ o) [1..] (opcoes p))