module Logica where

import Modelo
import System.Random (randomRIO)

-- | Busca perguntas por categoria usando compreensão de listas
buscarPorCategoria :: [Pergunta] -> Categoria -> [Pergunta]
buscarPorCategoria ps cat = [p | p <- ps, categoria p == cat]

-- | Lista todas as perguntas usando função de ordem superior
listarPerguntas :: [Pergunta] -> String
listarPerguntas ps = unlines $ map (\p -> exibir p ++ "\n") ps

-- | Embaralha perguntas usando um gerador aleatório
embaralharPerguntas :: [Pergunta] -> IO [Pergunta]
embaralharPerguntas ps = do
    indices <- sequence [randomRIO (i, length ps - 1) | i <- [0..length ps - 1]]
    return $ map (ps !!) (foldr (\i is -> if i `elem` is then is else i:is) [] indices)

-- | Calcula resultado final
calcularResultadoFinal :: ShowJ -> String
calcularResultadoFinal show =
    "Pontuação: " ++ show (pontuacao show) ++ "/" ++ show (length $ respondidas show) ++
    "\nPrêmio: R$" ++ show (premio show)

-- | Elimina duas opções incorretas
eliminarOpcoes :: Pergunta -> IO (Pergunta, [Int])
eliminarOpcoes p = do
    let corretaIdx = correta p
    incorretas <- sequence [randomRIO (1, length (opcoes p)) | _ <- [1,2]]
    let incorretasFiltradas = filter (/= corretaIdx) $ take 2 $ filter (<= length (opcoes p)) incorretas
    return (p, incorretasFiltradas)

-- | Simula consulta aos universitários
consultarUniversitarios :: Pergunta -> IO String
consultarUniversitarios p = do
    let corretaIdx = correta p
    prob <- randomRIO (1, 100) :: IO Int
    return $ "Os universitários sugerem: " ++ show corretaIdx ++ ". " ++ (opcoes p !! (corretaIdx - 1)) ++
             " (" ++ show prob ++ "% de confiança)"