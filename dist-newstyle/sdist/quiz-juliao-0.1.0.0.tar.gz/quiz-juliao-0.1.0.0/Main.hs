module Main where

import Modelo
import Logica
import System.IO
import Control.Exception (try, SomeException)
import Text.Read (readMaybe)
import System.Console.ANSI
import System.Directory (doesFileExist)
import Data.List (intercalate)

-- | Exemplo de perguntas iniciais
perguntasIniciais :: [Pergunta]
perguntasIniciais = [
    Pergunta "Quem descobriu o Brasil?" ["Vasco da Gama", "Pedro Álvares Cabral", "Cristóvão Colombo"] 2 Historia,
    Pergunta "O que é fotossíntese?" ["Processo de respiração", "Produção de energia pelas plantas", "Decomposição"] 2 Ciencias,
    Pergunta "Quem canta 'Thriller'?" ["Michael Jackson", "Elvis Presley", "Madonna"] 1 CulturaPop,
    Pergunta "Qual é a capital da França?" ["Paris", "Londres", "Berlim"] 1 Historia,
    Pergunta "O que é H2O?" ["Água", "Oxigênio", "Hidrogênio"] 1 Ciencias,
    Pergunta "Quem dirigiu 'Titanic'?" ["Spielberg", "Cameron", "Nolan"] 2 CulturaPop
    ]

-- | Lista de prêmios
premios :: [Int]
premios = [1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000]

-- | Menu estilizado
menu :: String
menu = unlines [
    "\ESC[1;34m╔══════════════════════════════╗\ESC[0m",
    "\ESC[1;34m║        SHOW DO JULIÃO        ║\ESC[0m",
    "\ESC[1;34m╚══════════════════════════════╝\ESC[0m",
    "\ESC[1;33m1. Iniciar Show\ESC[0m",
    "\ESC[1;33m2. Adicionar Pergunta\ESC[0m",
    "\ESC[1;33m3. Remover Pergunta\ESC[0m",
    "\ESC[1;33m4. Listar Perguntas por Categoria\ESC[0m",
    "\ESC[1;33m5. Salvar Perguntas em Arquivo\ESC[0m",
    "\ESC[1;33m6. Carregar Perguntas de Arquivo\ESC[0m",
    "\ESC[1;33m7. Sair\ESC[0m",
    "\ESC[1;34mDigite sua opção:\ESC[0m "
    ]

-- | Função principal
main :: IO ()
main = do
    hSetBuffering stdout NoBuffering
    setTitle "Show do Julião"
    putStrLn "\ESC[2J\ESC[H" -- Limpa o terminal
    loop $ novoShow perguntasIniciais

-- | Loop principal do programa
loop :: ShowJ -> IO ()
loop show = do
    putStrLn menu
    opcao <- getLine
    case opcao of
        "1" -> iniciarShow show >>= loop
        "2" -> adicionarNovaPergunta show >>= loop
        "3" -> removerPerguntaInterativo show >>= loop
        "4" -> listarPorCategoria show >>= loop
        "5" -> salvarPerguntas show >>= loop
        "6" -> carregarPerguntas show >>= loop
        "7" -> putStrLn "\ESC[1;31mObrigado por jogar o Show do Julião!\ESC[0m" >> return ()
        _   -> putStrLn "\ESC[1;31mOpção inválida!\ESC[0m" >> loop show

-- | Inicia o show com perguntas embaralhadas
iniciarShow :: ShowJ -> IO ShowJ
iniciarShow show = do
    putStrLn "\ESC[2J\ESC[H\ESC[1;34mBem-vindo ao Show do Julião!\ESC[0m"
    perguntasEmbaralhadas <- embaralharPerguntas $ perguntas show
    executarPerguntas show perguntasEmbaralhadas 0

-- | Executa cada pergunta do show
executarPerguntas :: ShowJ -> [Pergunta] -> Int -> IO ShowJ
executarPerguntas show [] _ = do
    putStrLn $ "\ESC[1;32m" ++ calcularResultadoFinal show ++ "\ESC[0m"
    return show
executarPerguntas show (p:ps) nivel = do
    putStrLn $ "\ESC[1;33mPergunta valendo R$" ++ show (premios !! min nivel (length premios - 1)) ++ "\ESC[0m"
    putStrLn $ exibir p
    putStrLn $ "\ESC[1;36mAjudas disponíveis: " ++ show (ajudas show) ++ "\ESC[0m"
    putStrLn "\ESC[1;34m1. Responder  2. Parar  3. Usar Ajuda\ESC[0m"
    putStr "Sua escolha: "
    escolha <- getLine
    case escolha of
        "1" -> do
            putStr "Digite sua resposta (número): "
            resp <- getLine
            case readMaybe resp :: Maybe Int of
                Just r -> do
                    let novoShow = responderPergunta show p r
                    if r == correta p
                        then putStrLn "\ESC[1;32mCorreto!\ESC[0m" >> executarPerguntas novoShow ps (nivel + 1)
                        else putStrLn "\ESC[1;31mErrado! Você leva R$" ++ show (premio show) ++ "\ESC[0m" >> return show
                Nothing -> putStrLn "\ESC[1;31mEntrada inválida! Digite um número.\ESC[0m" >> executarPerguntas show (p:ps) nivel
        "2" -> do
            putStrLn $ "\ESC[1;32mVocê parou com R$" ++ show (premio show) ++ "\ESC[0m"
            return show
        "3" -> usarAjudaInterativo show p ps nivel
        _ -> putStrLn "\ESC[1;31mEscolha inválida!\ESC[0m" >> executarPerguntas show (p:ps) nivel

-- | Usa uma ajuda interativamente
usarAjudaInterativo :: ShowJ -> Pergunta -> [Pergunta] -> Int -> IO ShowJ
usarAjudaInterativo show p ps nivel = do
    putStrLn "\ESC[1;36mEscolha uma ajuda: Pular, Eliminar, Universitarios\ESC[0m"
    ajudaStr <- getLine
    case readMaybe ajudaStr :: Maybe Ajuda of
        Just ajuda | ajuda `elem` ajudas show -> do
            let novoShow = usarAjuda show ajuda
            case ajuda of
                Pular -> do
                    putStrLn "\ESC[1;33mPergunta pulada!\ESC[0m"
                    executarPerguntas novoShow ps nivel
                Eliminar -> do
                    (p', eliminadas) <- eliminarOpcoes p
                    putStrLn $ "\ESC[1;33mEliminadas as opções: " ++ intercalate ", " (map show eliminadas) ++ "\ESC[0m"
                    putStrLn $ exibir p'
                    executarPerguntas novoShow (p':ps) nivel
                Universitarios -> do
                    resultado <- consultarUniversitarios p
                    putStrLn $ "\ESC[1;33m" ++ resultado ++ "\ESC[0m"
                    executarPerguntas novoShow (p:ps) nivel
        _ -> putStrLn "\ESC[1;31mAjuda inválida ou não disponível!\ESC[0m" >> executarPerguntas show (p:ps) nivel

-- | Adiciona uma nova pergunta
adicionarNovaPergunta :: ShowJ -> IO ShowJ
adicionarNovaPergunta show = do
    putStrLn "\ESC[1;34mDigite o texto da pergunta:\ESC[0m"
    texto <- getLine
    putStrLn "\ESC[1;34mDigite as opções (uma por linha, termine com linha vazia):\ESC[0m"
    opcoes <- coletarOpcoes []
    putStrLn "\ESC[1;34mDigite o número da opção correta:\ESC[0m"
    corretaStr <- getLine
    case readMaybe corretaStr :: Maybe Int of
        Just correta -> do
            putStrLn "\ESC[1;34mDigite a categoria (Historia, Ciencias, CulturaPop):\ESC[0m"
            catStr <- getLine
            case readMaybe catStr :: Maybe Categoria of
                Just categoria -> do
                    let novaPergunta = Pergunta texto opcoes correta categoria
                    putStrLn "\ESC[1;32mPergunta adicionada com sucesso!\ESC[0m"
                    return $ adicionarPergunta show novaPergunta
                Nothing -> putStrLn "\ESC[1;31mCategoria inválida! Use Historia, Ciencias ou CulturaPop.\ESC[0m" >> adicionarNovaPergunta show
        Nothing -> putStrLn "\ESC[1;31mEntrada inválida para a opção correta! Digite um número.\ESC[0m" >> adicionarNovaPergunta show

-- | Coleta opções
coletarOpcoes :: [String] -> IO [String]
coletarOpcoes acc = do
    opcao <- getLine
    if null opcao
        then return acc
        else coletarOpcoes (opcao : acc)

-- | Remove uma pergunta
removerPerguntaInterativo :: ShowJ -> IO ShowJ
removerPerguntaInterativo show = do
    putStrLn "\ESC[1;34mDigite o texto da pergunta a remover:\ESC[0m"
    texto <- getLine
    putStrLn "\ESC[1;32mPergunta removida (se existia)!\ESC[0m"
    return $ removerPergunta show texto

-- | Lista perguntas por categoria
listarPorCategoria :: ShowJ -> IO ShowJ
listarPorCategoria show = do
    putStrLn "\ESC[1;34mDigite a categoria (Historia, Ciencias, CulturaPop):\ESC[0m"
    catStr <- getLine
    case readMaybe catStr :: Maybe Categoria of
        Just categoria -> do
            putStrLn $ "\ESC[1;33m" ++ listarPerguntas (buscarPorCategoria (perguntas show) categoria) ++ "\ESC[0m"
            return show
        Nothing -> putStrLn "\ESC[1;31mCategoria inválida! Use Historia, Ciencias ou CulturaPop.\ESC[0m" >> listarPorCategoria show

-- | Salva perguntas em um arquivo
salvarPerguntas :: ShowJ -> IO ShowJ
salvarPerguntas show = do
    let arquivo = "perguntas.txt"
    writeFile arquivo $ unlines $ map show (perguntas show)
    putStrLn $ "\ESC[1;32mPerguntas salvas em " ++ arquivo ++ "!\ESC[0m"
    return show

-- | Carrega perguntas de um arquivo
carregarPerguntas :: ShowJ -> IO ShowJ
carregarPerguntas show = do
    let arquivo = "perguntas.txt"
    existe <- doesFileExist arquivo
    if existe
        then do
            conteudo <- readFile arquivo
            let perguntasLidas = map (read :: String -> Pergunta) (lines conteudo)
            putStrLn "\ESC[1;32mPerguntas carregadas com sucesso!\ESC[0m"
            return $ novoShow (perguntasLidas ++ perguntas show)
        else do
            putStrLn "\ESC[1;31mArquivo não encontrado!\ESC[0m"
            return show